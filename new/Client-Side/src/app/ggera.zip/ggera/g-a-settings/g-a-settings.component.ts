import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-g-a-settings',
  templateUrl: './g-a-settings.component.html',
  styleUrls: ['./g-a-settings.component.scss']
})
export class GASettingsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
