import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chat-screen',
  templateUrl: './chat-screen.component.html',
  styleUrls: ['./chat-screen.component.scss']
})
export class ChatScreenComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
