import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-party-list',
  templateUrl: './party-list.component.html',
  styleUrls: ['./party-list.component.scss']
})
export class PartyListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
