import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-party-payment-failed',
  templateUrl: './party-payment-failed.component.html',
  styleUrls: ['./party-payment-failed.component.scss']
})
export class PartyPaymentFailedComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
