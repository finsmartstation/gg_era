import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-order-normal',
  templateUrl: './my-order-normal.component.html',
  styleUrls: ['./my-order-normal.component.scss']
})
export class MyOrderNormalComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
